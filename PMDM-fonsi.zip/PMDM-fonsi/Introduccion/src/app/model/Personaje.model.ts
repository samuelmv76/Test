/*export class Personaje{
  
        nombre: string,
        raza: string,
        poder: number,
        imagen: string
    
}*/